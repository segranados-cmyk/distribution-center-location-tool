'use strict';

// Netlify Function: retrieves ACS data server-side; never sends the API key to browsers.
const STATES = new Set('01 02 04 05 06 08 09 10 12 13 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 44 45 46 47 48 49 50 51 53 54 55 56'.split(' '));
const FIELDS = ['NAME','B01003_001E','B19013_001E','B20002_001E','B11001_001E',
  ...Array.from({length:13},(_,i)=>`B01001_${String(i+7).padStart(3,'0')}E`),
  ...Array.from({length:13},(_,i)=>`B01001_${String(i+31).padStart(3,'0')}E`)];
const CENSUS_ENDPOINT = 'https://api.census.gov/data/2024/acs/acs5';
const HEADERS = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=300, s-maxage=3600'};
let lastGood = null;

function reply(statusCode, body) { return {statusCode, headers:statusCode===200?HEADERS:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store, max-age=0'}, body:JSON.stringify(body)}; }
function makeUrl(fields, useKey) {
  // Build a query string without depending on the URL constructor.
  const params = 'get=' + encodeURIComponent(fields.join(',')) + '&for=state%3A%2A';
  const key = useKey && process.env.CENSUS_API_KEY ? '&key=' + encodeURIComponent(process.env.CENSUS_API_KEY) : '';
  return CENSUS_ENDPOINT + '?' + params + key;
}
async function request(fields, useKey, ms) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    const response = await fetch(makeUrl(fields,useKey), {headers:{Accept:'application/json'},signal:controller.signal});
    if (!response.ok) throw Error(`Census HTTP ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data) || !Array.isArray(data[0]) || !data[0].includes('state')) throw Error('Invalid Census response');
    return data;
  } finally { clearTimeout(timer); }
}
function filterStates(data) {
  const index=data[0].indexOf('state');
  return [data[0], ...data.slice(1).filter(row=>STATES.has(row[index]))];
}
async function splitRequest() {
  // Smaller queries can succeed if the Census service struggles with the full field list.
  const first = ['NAME','B01003_001E','B19013_001E','B20002_001E','B11001_001E'];
  const second = ['NAME',...FIELDS.slice(5)];
  const [a,b] = await Promise.all([request(first,false,6500),request(second,false,6500)]);
  const map = new Map(b.slice(1).map(row=>[row[b[0].indexOf('state')],Object.fromEntries(b[0].map((field,i)=>[field,row[i]]))]));
  const merged = a.slice(1).map(row=>{
    const base=Object.fromEntries(a[0].map((field,i)=>[field,row[i]]));
    const other=map.get(base.state);
    return other ? FIELDS.map(field=>base[field] ?? other[field]).concat(base.state) : null;
  }).filter(Boolean);
  return [FIELDS.concat('state'),...merged];
}
exports.handler = async () => {
  const failures=[];
  const attempts=[
    {label:'standard',run:()=>request(FIELDS,Boolean(process.env.CENSUS_API_KEY),6500)},
    {label:'without API key',run:()=>request(FIELDS,false,6500)},
    {label:'smaller Census requests',run:splitRequest}
  ];
  for (const attempt of attempts) {
    try {
      const data=filterStates(await attempt.run());
      if (data.length < 3) throw Error('Too few state records returned');
      lastGood=data;
      return reply(200,data);
    } catch (error) {
      const detail=error.name==='AbortError'?'timed out':error.message;
      failures.push(`${attempt.label}: ${detail}`);
      console.warn('Census attempt failed:',attempt.label,detail);
    }
  }
  if (lastGood) {
    console.warn('Returning cached Census data after upstream failures');
    return reply(200,lastGood);
  }
  return reply(502,{error:'Census data is temporarily unavailable after three attempts.',details:failures.join('; ')});
};
